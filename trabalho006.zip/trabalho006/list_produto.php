<?php

    $item = array
    (
       0 => array 
        (
            "nome" => "MacBook Air 13 polegadas",
            "produto" => "Notebook",
            "preco" => 13499.99,
            "quantidade" => 1,
            "marca" => "Apple",
            "imagem" => "https://m.media-amazon.com/images/I/51B-aeCQTCL._AC_UL480_FMwebp_QL65_.jpg"
        ),
        1 => array 
        (
            "nome" => "APPYAUDIO W1",
            "produto" => "Fones de ouvido",
            "preco" => 99.99,
            "quantidade" => 1,
            "marca" => "HAPPYAUDIO",
            "imagem" => "https://m.media-amazon.com/images/I/51E++4C8QgS._AC_UL480_FMwebp_QL65_.jpg"

        ),
        2 => array 
        (
            "nome" => "Monitor Gamer Samsung",
            "produto" => "Monitor",
            "preco" => 769.99,
            "quantidade" => 1,
            "marca" => "SAMSUNG",
            "genero" => "tecnologia",
            "imagem" => "https://m.media-amazon.com/images/I/617yiTTtunL._AC_UL480_FMwebp_QL65_.jpg"

        ),
        3 => array 
        (
            "nome" => "Mouse Óptico Usb 1200dpi Preto",
            "produto" => "Mouse",
            "preco" => 16.99,
            "quantidade" => 1,
            "marca" => "Unicaserv",
            "imagem" => "https://m.media-amazon.com/images/I/71KkP20to1L._AC_UL480_FMwebp_QL65_.jpg"

        ),
        4 => array 
        (
            "nome" => "Impressora Multifuncional Canon Maxify Mega Tank GX6010 Wi-fi",
            "produto" => "Impressora",
            "preco" => 3399.99,
            "quantidade" => 1,
            "marca" => "Canon",
            "imagem" => "https://m.media-amazon.com/images/I/51ltScNypmL._AC_UL480_FMwebp_QL65_.jpg"

        ),
        5 => array 
        (
            "nome" => "Smartphone Motorola Moto E20 32GB 2GB RAM, Azul",
            "produto" => "Smartphone",
            "preco" => 699.99,
            "quantidade" => 1,
            "marca" => "Motorola",
            "imagem" => "https://m.media-amazon.com/images/I/51CdNBzgLpL._AC_UL480_FMwebp_QL65_.jpg"

        ),
        6 => array 
        (
            "nome" => "Gabinete Gamer Mid Tower HOLT RGB Fortrek",
            "produto" => "Gabinete",
            "preco" => 219.99,
            "quantidade" => 1,
            "marca" => "Fortrek",
            "imagem" => "https://m.media-amazon.com/images/I/71a8zCo+oLL._AC_UL480_FMwebp_QL65_.jpg"

        ),
        7 => array 
        (
            "nome" => "Sandisk Ultra Shift Usb 3.0 Flash Drive 64Gb",
            "produto" => "Pendrive",
            "preco" => 28.99,
            "quantidade" => 1,
            "marca" => "SanDisk",
            "imagem" => "https://m.media-amazon.com/images/I/61sA8i+yO3L._AC_UL480_FMwebp_QL65_.jpg"

        ),
    );

?>