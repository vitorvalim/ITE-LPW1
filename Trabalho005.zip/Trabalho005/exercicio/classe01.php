<?php
/*
classe cliente
-nome
-cpf
-saldo
funcao

*/
    include("../classes/banco.php");
    class Cliente extends Banco
    {
        public $nome;
        public $cpf;
        public $possui_emprestimo = false;
        public $v_emprestimo;
        public function emprestimo($valor)
        {
            if($this->possui_emprestimo)
            {
                echo "</br>Infelismente não podemos".
                    " abrir outro emprestimo";
            }
            else
            {
                $this->possui_emprestimo = true;
                $this->depositar($valor);
                $this->v_emprestimo = $valor;
            }
        }
        public function quitacao($v_quitacao)
        {
            if($this->possui_emprestimo)
            {
                if ($this->v_emprestimo == $v_quitacao) 
                {
                        $this->sacar($v_quitacao);
                        echo "</br>Quitação realizada";
                }
                else
                {
                    echo "</br>Quitação não realizada";
                    var_dump($this->possui_emprestimo);

                }
            }
            else
            {
                echo "</br>Sem Emprestimo";
            }
        }
    }

    $pessoa = new Cliente();
    $pessoa->nome = "Alberto";
    $pessoa->cpf = "333535325";
    $pessoa->saldo = 1000;
    $pessoa->depositar(800);
    
    echo "<br/>O saldo atual de". $pessoa->nome ." é R$". $pessoa->saldo;

    $pessoa->emprestimo(8000);

    echo "<br/>O saldo atual de ". $pessoa->nome ." é R$". $pessoa->saldo;
    $pessoa->quitacao(8000);

    echo "<br/>O saldo atual de ". $pessoa->nome ." é R$". $pessoa->saldo;

?>  